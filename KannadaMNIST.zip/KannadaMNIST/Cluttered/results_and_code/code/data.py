#!/usr/bin/env python

# Created by Mohamed Elsayed
import numpy as np, os

from scipy import misc
from sklearn.utils import shuffle
from PIL import Image, ImageDraw, ImageFont

# create cluttered MNIST
def clutter(batch, w_o):
    train_data = batch
    n, w_i, w_i = batch.shape[:3]
#    w_i = 28
#    w_o = 60
    data = np.zeros(shape=(n,w_o,w_o), dtype=np.float32)
    for k in range(n):
        i, j = np.random.randint(0, w_o-w_i, size=2)
        data[k, i:i+w_i, j:j+w_i] += batch[k]
        for _ in range(4):
            clt = train_data[np.random.randint(0, train_data.shape[0]-1)]
#            clt = train_data[np.random.randint(0, train_data.shape[0]-1)]
            c1, c2 = np.random.randint(0, w_i-8, size=2)
            i1, i2 = np.random.randint(0, w_o-8, size=2)
            data[k, i1:i1+8, i2:i2+8] += clt[c1:c1+8, c2:c2+8]
#        print("hi")
        data[k, i-4:i+w_i+4, j-4:j+w_i+4] = 0
        data[k, i:i+w_i, j:j+w_i] += batch[k]
    data = np.clip(data, 0., 1.)
    return data
# create searching MNIST
def search_target(batch, w_o, labels):
    train_data = batch
    n, w_i, w_i = batch.shape[:3]
#    w_o = 60
    gap_between_two = 0
    num_distractors = 3
    range_ = w_o//num_distractors
    row_range = (np.arange((w_o//range_)))
    shuffle(row_range)
    
    col_range = (np.arange((w_o//range_)))
    shuffle(col_range)
    
    data = np.zeros(shape=(n,w_o,w_o), dtype=np.float32)
    for k in range(n):
        
        target_class = labels[k]
        for d in range(num_distractors):
            distractor = np.random.randint(0, train_data.shape[0]-1)
            distractor_class = labels[distractor]
#            print(d)
            if distractor_class != target_class:
                clt = train_data[distractor]
#                r = np.random.randint(0, np.max(row_range), size=1)
                i1, i2 = np.random.randint((range_*row_range[d])+0+gap_between_two, (range_*col_range[d])+range_-w_i-gap_between_two, size=2)
#                print(d,i1,i2, d, row_range[d], col_range[d], range_, (range_*row_range[d])+0, (range_*col_range[d])+range_-w_i)
                data[k, i1:i1+w_i, i2:i2+w_i] += clt#[c1:c1+8, c2:c2+8]
                
        r = np.random.randint(0, np.max(row_range), size=1)
        i, j = np.random.randint((range_*row_range[r])+0+gap_between_two, (range_*col_range[r+1])+range_-w_i-gap_between_two, size=2)
        data[k, i:i+w_i, j:j+w_i] += batch[k]
        
    data = np.clip(data, 0., 1.)
    return data
# create translated MNIST
def translate(batch, w_o):
    n, w_i, w_i = batch.shape[:3]
#    w_o = 60
    data = np.zeros(shape=(n,w_o,w_o), dtype=np.float32)
    for k in range(n):
        i, j = np.random.randint(0, w_o-w_i, size=2)
        data[k, i:i+w_i, j:j+w_i] += batch[k]
    return data


(TrainingData, TrainingLables, start) = ([], [], 0)
(TestingData, TestingLables, startT) = ([], [], 0)

def LoadTestingData(Dir, Img_Shape, no_class):
    (Images, Lbls, Labels, ID, NClasses) = ([], [], [], 0, 0)
    class_ = 0
    for(_, Dirs, _) in os.walk(Dir):
        Dirs = sorted(Dirs)
        if class_ <= no_class:
            for SubDir in Dirs:
                class_ += 1
                SubjectPath = os.path.join(Dir, SubDir)
                for FileName in os.listdir(SubjectPath):
                    path = SubjectPath + "/" + FileName
                    Img = np.array(Image.open(path))#misc.imread(path, mode='L')
    
                    #print Img.shape
                    (img_row, img_col) = Img.shape
    
    #                if(width != Img_Shape[0] or height != Img_Shape[1]):
    #                    Img = Img.resize((Img_Shape[0], Img_Shape[1]))
    
                    Images.append(Img)
    
                    Lbls.append(int(ID))
    
                NClasses += 1
    
                ID += 1

#    Images, Lbls = shuffle(Images, Lbls)

    Images = np.asarray(Images, dtype='float32').reshape([-1, img_row, img_col, 1]) 

    #print "Classes: " + str(NClasses)

    for label in Lbls:
        Labels.append(Categorical_([label], NClasses)[0])

    return (Images, np.asarray(Labels))

def LoadTrainingData(Dir, Img_Shape, no_class):
    (Images, Labels, Names, Classes, Paths, ID, NClasses) = ([], [], [], [], [], 0, 0)
    class_ = 0
    for(_, Dirs, _) in os.walk(Dir):
        Dirs = sorted(Dirs)
        if class_ <= no_class:
            for SubDir in Dirs:
                class_ += 1
                SubjectPath = os.path.join(Dir, SubDir)
                for FileName in os.listdir(SubjectPath):
                    path = SubjectPath + "/" + FileName
                    Img = np.array(Image.open(path))#misc.imread(path, mode='L')
                    Paths.append(path)
    
                    #print Img.shape
                    (img_row, img_col) = Img.shape
    
    #                if(width != Img_Shape[0] or height != Img_Shape[1]):
    #                    Img = Img.resize((Img_Shape[0], Img_Shape[1]))
    
                    Images.append(Img)
    
                    Labels.append(int(ID))
                    Names.append(SubDir)
                Classes.append(SubDir)
    
                NClasses += 1
    
                ID += 1

    Images, Labels = shuffle(Images, Labels)
    
    Images = np.asarray(Images, dtype='float32').reshape([-1, img_row, img_col, 1]) 

    lbls = []
    for label in Labels:
        lbls.append(Categorical_([label], NClasses)[0])

    return (Images, lbls, np.asarray(Names), np.asarray(Classes), np.asarray(Paths))


def Categorical(y, NClasses):
#    print("NClasses",NClasses)
    y = np.asarray(y, dtype='int32')
    if not NClasses:
        NClasses = np.max(y)+1
    Y = np.zeros((len(y), NClasses))
    for i in range(len(y)):
        Y[i, y[i]] = 1.
    return Y

def Categorical_(y, NClasses):
    y = np.asarray(y, dtype='int32')
    if not NClasses:
        NClasses = np.max(y)+1
    Y = np.zeros((len(y), 1))
    for i in range(len(y)):
        Y[i, 0] = y[i]
    return Y

def nextBatch(batchSize):
    global start
    end = start + batchSize

    #print "Start: " + str(start)
    #print "End: " + str(end)
    if(end > len(TrainingData)):
        X,Y = TrainingData[start:], TrainingLables[start:]
        start = 0
        return X, Y

    (X, Y) = (TrainingData[start: end], TrainingLables[start: end])
    start = end
    #X = X.reshape(len(X), X[0].size)
    if (end == len(TrainingData)):
        start = 0

    return X, Y

def nextTestBatch(batchSize):
    global startT
    end = startT + batchSize

    #print "Start: " + str(start)
    #print "End: " + str(end)
    if(end > len(TestingData)):
        X,Y = TestingData[startT:], TestingLables[startT:]
        startT = 0
        return X, Y

    (X, Y) = (TestingData[startT: end], TestingLables[startT: end])
    startT = end
    if(end == len(TestingData)):
        startT = 0
    #X = X.reshape(len(X), X[0].size)


    return X, Y

#def plot_face_img():
#    
#    validName = str(NamesT[i])
#    predictedName = str(NamesT[p])
#
#    print(str(p) + "-PreTest: " + validName + " --> Test: " + NamesT[p])
#
#    TestImg = Image.open(Paths[i]).convert('RGBA')
#    draw = ImageDraw.Draw(TestImg)
#    font = ImageFont.truetype("/usr/share/fonts/dejavu/DejaVuSans.ttf", 12)
#
#    txt = Image.new('RGBA', TestImg.size, (255, 255, 255, 0))
#
#    draw = ImageDraw.Draw(txt)
#
#    draw.text((0, 0), validName, font=font, fill=(0, 255, 0, 255))
#
#    if (validName == predictedName):
#        draw.text((imageWidth - 25, 0), predictedName, font=font, fill=(0, 255, 0, 255))
#    else:
#        draw.text((imageWidth - 25, 0), predictedName, font=font, fill=(255, 0, 0, 255))
#
#    TestImg = Image.alpha_composite(TestImg, txt)
#
#    TestImg.show()
#    
#    from PIL import Image, ImageDraw, ImageFont
#    i = 0
#    validName = str(NamesT[i])
#
#    TestImg = Image.open(Paths[i])#.convert('RGBA')
##    draw = ImageDraw.Draw(TestImg)
#    # use a bitmap font
##    font = ImageFont.load("arial.pil")
##
##    font = ImageFont.truetype("arial.pil", 12)
#
##    txt = Image.new('RGBA', TestImg.size, (255, 255, 255, 0))
#
##    draw = ImageDraw.Draw(txt)
#
##    draw.text((0, 0), validName, fill=(0, 255, 0, 255))
#
##    if (validName == predictedName):
##        draw.text((imageWidth - 25, 0), predictedName, font=font, fill=(0, 255, 0, 255))
##    else:
##    draw.text((92 - 25, 0), fill=(255, 0, 0, 255))
#
##    TestImg = Image.alpha_composite(TestImg, txt)
#
#    TestImg.show()
